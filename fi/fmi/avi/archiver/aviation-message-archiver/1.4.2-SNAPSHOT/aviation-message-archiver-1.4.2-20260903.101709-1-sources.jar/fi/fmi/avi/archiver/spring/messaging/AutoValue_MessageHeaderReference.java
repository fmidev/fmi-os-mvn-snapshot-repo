package fi.fmi.avi.archiver.spring.messaging;

import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_MessageHeaderReference<T> extends MessageHeaderReference<T> {

  private final String name;

  private final Class<T> type;

  AutoValue_MessageHeaderReference(
      String name,
      Class<T> type) {
    if (name == null) {
      throw new NullPointerException("Null name");
    }
    this.name = name;
    if (type == null) {
      throw new NullPointerException("Null type");
    }
    this.type = type;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public Class<T> getType() {
    return type;
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof MessageHeaderReference) {
      MessageHeaderReference<?> that = (MessageHeaderReference<?>) o;
      return this.name.equals(that.getName())
          && this.type.equals(that.getType());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= name.hashCode();
    h$ *= 1000003;
    h$ ^= type.hashCode();
    return h$;
  }

}
