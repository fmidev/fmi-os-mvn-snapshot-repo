package fi.fmi.avi.archiver.logging;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.function.Supplier;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_GenericStructuredLoggable_LazyValue<T> extends GenericStructuredLoggable.LazyValue<T> {

  private final String structureName;

  private final Supplier<T> valueSupplier;

  private final Supplier<String> stringSupplier;

  AutoValue_GenericStructuredLoggable_LazyValue(
      String structureName,
      Supplier<T> valueSupplier,
      Supplier<String> stringSupplier) {
    if (structureName == null) {
      throw new NullPointerException("Null structureName");
    }
    this.structureName = structureName;
    if (valueSupplier == null) {
      throw new NullPointerException("Null valueSupplier");
    }
    this.valueSupplier = valueSupplier;
    if (stringSupplier == null) {
      throw new NullPointerException("Null stringSupplier");
    }
    this.stringSupplier = stringSupplier;
  }

  @JsonIgnore
  @Override
  public String getStructureName() {
    return structureName;
  }

  @Override
  Supplier<T> getValueSupplier() {
    return valueSupplier;
  }

  @Override
  Supplier<String> getStringSupplier() {
    return stringSupplier;
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof GenericStructuredLoggable.LazyValue) {
      GenericStructuredLoggable.LazyValue<?> that = (GenericStructuredLoggable.LazyValue<?>) o;
      return this.structureName.equals(that.getStructureName())
          && this.valueSupplier.equals(that.getValueSupplier())
          && this.stringSupplier.equals(that.getStringSupplier());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= structureName.hashCode();
    h$ *= 1000003;
    h$ ^= valueSupplier.hashCode();
    h$ *= 1000003;
    h$ ^= stringSupplier.hashCode();
    return h$;
  }

}
