package fi.fmi.avi.archiver.logging.logback.logstash;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.spi.AppenderAttachable;
import ch.qos.logback.core.spi.AppenderAttachableImpl;
import com.google.common.annotations.VisibleForTesting;
import fi.fmi.avi.archiver.logging.NoOpLoggable;
import fi.fmi.avi.archiver.logging.StructuredLoggable;
import fi.fmi.avi.archiver.logging.logback.ForwardingAppenderBase;
import fi.fmi.avi.archiver.logging.logback.ForwardingLoggingEvent;
import net.logstash.logback.argument.StructuredArgument;
import net.logstash.logback.argument.StructuredArguments;
import org.jspecify.annotations.Nullable;

import static java.util.Objects.requireNonNull;

/**
 * An {@link Appender} that wraps received logging events, transforming any {@link StructuredLoggable} in event
 * {@link ILoggingEvent#getArgumentArray() arguments} into {@link StructuredArgument} of
 * <a href="https://github.com/logfellow/logstash-logback-encoder">Logstash Logback Encoder</a>, and forwards the wrapped event to attached appenders.
 * Wrapped logging events support <em>deferred processing</em> by requesting a {@link StructuredLoggable#readableCopy() copy} of {@code StructuredLoggable}
 * objects on {@link ILoggingEvent#prepareForDeferredProcessing() prepare}.
 */
public class StructuredLoggableLogstashAppender extends ForwardingAppenderBase<ILoggingEvent> {
    private final AppenderAttachableImpl<ILoggingEvent> appenders;

    public StructuredLoggableLogstashAppender() {
        this(new AppenderAttachableImpl<>());
    }

    @VisibleForTesting
    StructuredLoggableLogstashAppender(final AppenderAttachableImpl<ILoggingEvent> appenders) {
        this.appenders = requireNonNull(appenders, "appenders");
    }

    @Override
    protected AppenderAttachable<ILoggingEvent> appenders() {
        return appenders;
    }

    @Override
    protected void append(final @Nullable ILoggingEvent eventObject) {
        if (!isStarted() || eventObject == null) {
            return;
        }
        appenders.appendLoopOnAppenders(new LoggingEvent(eventObject));
    }

    @VisibleForTesting
    @SuppressWarnings("TransientFieldInNonSerializableClass")
    static final class LoggingEvent extends ForwardingLoggingEvent {
        private final ILoggingEvent delegate;

        private transient Object @Nullable [] argumentArray;
        private transient boolean argumentArrayPreparedForDeferredProcessing;

        LoggingEvent(final ILoggingEvent delegate) {
            this.delegate = requireNonNull(delegate, "delegate");
        }

        @Override
        protected ILoggingEvent delegate() {
            return delegate;
        }

        @Override
        public Object @Nullable [] getArgumentArray() {
            return getArgumentArray(false);
        }

        private Object @Nullable [] getArgumentArray(final boolean prepareForDeferredProcessing) {
            if (!argumentArrayPreparedForDeferredProcessing && (prepareForDeferredProcessing || argumentArray == null)) {
                // Above condition ensures this is invoked at maximum twice:
                // 1. first time when prepareForDeferredProcessing == false and
                // 2. first time when prepareForDeferredProcessing == true, and never after
                initArgumentArray(prepareForDeferredProcessing);
            }
            return argumentArray;
        }

        private void initArgumentArray(final boolean copyStructuredLoggables) {
            final Object[] delegateArgumentArray = delegate().getArgumentArray();
            if (delegateArgumentArray == null) {
                argumentArray = null;
                argumentArrayPreparedForDeferredProcessing = true;
                return;
            }
            if (argumentArray == null) {
                argumentArray = delegateArgumentArray.clone();
                assert argumentArray != null : "argumentArray should be non-null";
            }
            for (int i = 0; i < delegateArgumentArray.length; i++) {
                if (delegateArgumentArray[i] instanceof StructuredLoggable && !(delegateArgumentArray[i] instanceof NoOpLoggable)) {
                    final StructuredLoggable structuredLoggable = copyStructuredLoggables //
                            ? ((StructuredLoggable) delegateArgumentArray[i]).readableCopy() //
                            : (StructuredLoggable) delegateArgumentArray[i];
                    argumentArray[i] = StructuredArguments.keyValue(structuredLoggable.getStructureName(), structuredLoggable);
                }
            }
            argumentArrayPreparedForDeferredProcessing |= copyStructuredLoggables;
        }

        @Override
        public void prepareForDeferredProcessing() {
            super.prepareForDeferredProcessing();
            getArgumentArray(true);
        }
    }
}
