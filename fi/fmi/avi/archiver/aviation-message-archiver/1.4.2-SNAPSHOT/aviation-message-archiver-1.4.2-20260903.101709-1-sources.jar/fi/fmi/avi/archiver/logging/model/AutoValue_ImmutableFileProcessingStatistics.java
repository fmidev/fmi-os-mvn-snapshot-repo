package fi.fmi.avi.archiver.logging.model;

import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ImmutableFileProcessingStatistics extends ImmutableFileProcessingStatistics {

  private final ReadableFileProcessingStatistics.ProcessingResult file;

  private final ImmutableFileProcessingStatistics.ImmutableResultStatistics bulletin;

  private final ImmutableFileProcessingStatistics.ImmutableResultStatistics message;

  AutoValue_ImmutableFileProcessingStatistics(
      ReadableFileProcessingStatistics.ProcessingResult file,
      ImmutableFileProcessingStatistics.ImmutableResultStatistics bulletin,
      ImmutableFileProcessingStatistics.ImmutableResultStatistics message) {
    if (file == null) {
      throw new NullPointerException("Null file");
    }
    this.file = file;
    if (bulletin == null) {
      throw new NullPointerException("Null bulletin");
    }
    this.bulletin = bulletin;
    if (message == null) {
      throw new NullPointerException("Null message");
    }
    this.message = message;
  }

  @Override
  public ReadableFileProcessingStatistics.ProcessingResult getFile() {
    return file;
  }

  @Override
  public ImmutableFileProcessingStatistics.ImmutableResultStatistics getBulletin() {
    return bulletin;
  }

  @Override
  public ImmutableFileProcessingStatistics.ImmutableResultStatistics getMessage() {
    return message;
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ImmutableFileProcessingStatistics) {
      ImmutableFileProcessingStatistics that = (ImmutableFileProcessingStatistics) o;
      return this.file.equals(that.getFile())
          && this.bulletin.equals(that.getBulletin())
          && this.message.equals(that.getMessage());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= file.hashCode();
    h$ *= 1000003;
    h$ ^= bulletin.hashCode();
    h$ *= 1000003;
    h$ ^= message.hashCode();
    return h$;
  }

}
