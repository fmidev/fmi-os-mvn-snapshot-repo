package fi.fmi.avi.archiver.logging.model;

import fi.fmi.avi.archiver.file.FileReference;
import java.util.Optional;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ImmutableLoggingContext extends ImmutableLoggingContext {

  private final Optional<FileReference> file;

  private final Optional<BulletinLogReference> bulletin;

  private final Optional<MessageLogReference> message;

  AutoValue_ImmutableLoggingContext(
      Optional<FileReference> file,
      Optional<BulletinLogReference> bulletin,
      Optional<MessageLogReference> message) {
    if (file == null) {
      throw new NullPointerException("Null file");
    }
    this.file = file;
    if (bulletin == null) {
      throw new NullPointerException("Null bulletin");
    }
    this.bulletin = bulletin;
    if (message == null) {
      throw new NullPointerException("Null message");
    }
    this.message = message;
  }

  @Override
  public Optional<FileReference> getFile() {
    return file;
  }

  @Override
  public Optional<BulletinLogReference> getBulletin() {
    return bulletin;
  }

  @Override
  public Optional<MessageLogReference> getMessage() {
    return message;
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ImmutableLoggingContext) {
      ImmutableLoggingContext that = (ImmutableLoggingContext) o;
      return this.file.equals(that.getFile())
          && this.bulletin.equals(that.getBulletin())
          && this.message.equals(that.getMessage());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= file.hashCode();
    h$ *= 1000003;
    h$ ^= bulletin.hashCode();
    h$ *= 1000003;
    h$ ^= message.hashCode();
    return h$;
  }

}
