package fi.fmi.avi.archiver.spring.integration.file.filters;

import java.nio.file.attribute.FileTime;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_AcceptUnchangedFileListFilter_FileProperties extends AcceptUnchangedFileListFilter.FileProperties {

  private final FileTime lastModified;

  private final long size;

  AutoValue_AcceptUnchangedFileListFilter_FileProperties(
      FileTime lastModified,
      long size) {
    if (lastModified == null) {
      throw new NullPointerException("Null lastModified");
    }
    this.lastModified = lastModified;
    this.size = size;
  }

  @Override
  public FileTime getLastModified() {
    return lastModified;
  }

  @Override
  public long getSize() {
    return size;
  }

  @Override
  public String toString() {
    return "FileProperties{"
        + "lastModified=" + lastModified + ", "
        + "size=" + size
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof AcceptUnchangedFileListFilter.FileProperties) {
      AcceptUnchangedFileListFilter.FileProperties that = (AcceptUnchangedFileListFilter.FileProperties) o;
      return this.lastModified.equals(that.getLastModified())
          && this.size == that.getSize();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= lastModified.hashCode();
    h$ *= 1000003;
    h$ ^= (int) ((size >>> 32) ^ size);
    return h$;
  }

}
