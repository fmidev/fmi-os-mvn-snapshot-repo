package fi.fmi.avi.converter.tac.lexer.impl.token;

import fi.fmi.avi.converter.ConversionHints;
import fi.fmi.avi.converter.tac.lexer.Lexeme;
import fi.fmi.avi.converter.tac.lexer.LexemeIdentity;
import fi.fmi.avi.converter.tac.lexer.SerializingException;
import fi.fmi.avi.converter.tac.lexer.impl.FactoryBasedReconstructor;
import fi.fmi.avi.converter.tac.lexer.impl.ReconstructorContext;
import fi.fmi.avi.converter.tac.lexer.impl.RegexMatchingLexemeVisitor;
import fi.fmi.avi.model.AviationWeatherMessageOrCollection;
import fi.fmi.avi.model.PartialOrCompleteTimeInstant;
import fi.fmi.avi.model.swx.amd79.SpaceWeatherAdvisoryAmd79;
import fi.fmi.avi.model.swx.amd82.SpaceWeatherAdvisoryAmd82;

import java.time.DateTimeException;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAccessor;
import java.util.Locale;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.regex.Matcher;

public class AdvisoryPhenomenaTimeGroup extends RegexMatchingLexemeVisitor {

    // Note that this accepts hour 24 and parses it into 0 even though it should throw an exception according to the Javadoc
    private static final DateTimeFormatter ADVISORY_PHENOMENA_TIME_FORMAT = DateTimeFormatter.ofPattern("dd/HHmm'Z'");
    private static final int INVALID_MIDNIGHT = 24;

    public AdvisoryPhenomenaTimeGroup(final OccurrenceFrequency prio) {
        super("^(?<day>[0-9]{2})/(?<hour>[0-9]{2})(?<minute>[0-9]{2})Z$", prio);
    }

    @Override
    public void visitIfMatched(final Lexeme token, final Matcher match, final ConversionHints hints) {
        if (token != null && token.hasPrevious()) {
            if (token.getPrevious().getIdentity() != null && LexemeIdentity.ADVISORY_PHENOMENA_LABEL.equals(token.getPrevious().getIdentity())) {
                token.identify(LexemeIdentity.ADVISORY_PHENOMENA_TIME_GROUP);
                final int hour = Integer.parseInt(match.group("hour"));
                if (hour < INVALID_MIDNIGHT) {
                    try {
                        final TemporalAccessor parsed = ADVISORY_PHENOMENA_TIME_FORMAT.parse(token.getTACToken());
                        token.setParsedValue(Lexeme.ParsedValueName.DAY1, parsed.get(ChronoField.DAY_OF_MONTH));
                        token.setParsedValue(Lexeme.ParsedValueName.HOUR1, parsed.get(ChronoField.HOUR_OF_DAY));
                        token.setParsedValue(Lexeme.ParsedValueName.MINUTE1, parsed.get(ChronoField.MINUTE_OF_HOUR));
                    } catch (final DateTimeException e) {
                        // NOOP, ignore silently if the time is not valid
                    }
                }
            }
        }
    }

    public static class Reconstructor extends FactoryBasedReconstructor {
        @Override
        public <T extends AviationWeatherMessageOrCollection> Optional<Lexeme> getAsLexeme(final T msg, final Class<T> clz, final ReconstructorContext<T> ctx)
                throws SerializingException {
            Optional<Lexeme> retval = Optional.empty();

            if (SpaceWeatherAdvisoryAmd82.class.isAssignableFrom(clz)) {
                final Optional<Integer> index = ctx.getParameter("analysisIndex", Integer.class);
                if (index.isPresent()) {
                    final fi.fmi.avi.model.swx.amd82.SpaceWeatherAdvisoryAnalysis analysis = ((SpaceWeatherAdvisoryAmd82) msg).getAnalyses().get(index.get());
                    final String lexemeValue = getLexemeValue(analysis.getTime());
                    retval = Optional.of(this.createLexeme(lexemeValue, LexemeIdentity.ADVISORY_PHENOMENA_TIME_GROUP));
                }
            } else if (SpaceWeatherAdvisoryAmd79.class.isAssignableFrom(clz)) {
                final Optional<Integer> index = ctx.getParameter("analysisIndex", Integer.class);
                if (index.isPresent()) {
                    final fi.fmi.avi.model.swx.amd79.SpaceWeatherAdvisoryAnalysis analysis = ((SpaceWeatherAdvisoryAmd79) msg).getAnalyses().get(index.get());
                    final String lexemeValue = getLexemeValue(analysis.getTime());
                    retval = Optional.of(this.createLexeme(lexemeValue, LexemeIdentity.ADVISORY_PHENOMENA_TIME_GROUP));
                }
            }
            return retval;
        }

        private String getLexemeValue(final PartialOrCompleteTimeInstant timeInstant) throws SerializingException {
            final StringBuilder builder = new StringBuilder();
            if (timeInstant.getCompleteTime().isPresent()) {
                builder.append(timeInstant.getCompleteTime().get().format(ADVISORY_PHENOMENA_TIME_FORMAT));
            } else if (timeInstant.getPartialTime().isPresent()) {
                final OptionalInt day = timeInstant.getPartialTime().get().getDay();
                final OptionalInt hour = timeInstant.getPartialTime().get().getHour();
                final OptionalInt minute = timeInstant.getPartialTime().get().getMinute();
                if (day.isPresent() && hour.isPresent() && minute.isPresent()) {
                    builder.append(String.format(Locale.US, "%02d/%02d%02dZ", day.getAsInt(), hour.getAsInt(), minute.getAsInt()));
                } else {
                    throw new SerializingException("Insufficient partial analysis time, day:" + day + ", hour:" + hour + ", minute:" + minute);
                }
            } else {
                throw new SerializingException("Analysis time is missing");
            }
            return builder.toString();
        }

    }

}
